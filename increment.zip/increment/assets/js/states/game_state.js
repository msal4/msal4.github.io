var GameState = {
    create: function() {
        //create 4 zombies to start with
        this.zombies = this.game.add.group();
        for (var j = 0; j < 2; j++) {
            for (var i = 0; i < 2; i++) {
                this.zombies.add(
                    new Zombie(
                        this.game.world.centerX + i * 32,
                        this.game.world.centerY + j * 32
                    )
                );
            }
        }

        //create humans each 5 seconds
        this.spawnHumans();

        var style = {font: "bold 20px Arial", fill: "#99f0f8"};
        this.game.add.sprite(0, 0, "zombieHeart").scale.set(0.7);
        this.zombiesHealthtext = this.game.add.text(
            35,
            4,
            this.totalHealth,
            style
        );
    },
    nextFire: 0,
    fireRate: 1000,
    score: 0,
    update: function() {
        //collision
        this.checkCollision();
        //check movement input
        this.checkInput();
        //human fire
        if (this.game.time.now > this.nextFire) {
            this.fire();
        }
        //update zombies health stat
        this.updateZombiesTextHealth();
    },
    spawnHumans: function() {
        this.humans = this.game.add.group();

        this.game.time.events.loop(
            Phaser.Timer.SECOND * 2,
            function() {
                this.humans.add(
                    new Human(
                        this.game.rnd.integerInRange(0, this.game.world.width),
                        this.game.rnd.integerInRange(0, this.game.world.height)
                    )
                );
                var index = this.humans.length - 1;
                this.humans.children[index].bullets = this.game.add.group();
                this.humans.children[index].bullets.enableBody = true;
                this.humans.children[index].bullets.physicsBodyType =
                    Phaser.Physics.ARCADE;

                this.humans.children[index].bullets.createMultiple(
                    50,
                    "bullet"
                );
                this.humans.children[index].bullets.setAll(
                    "checkWorldBounds",
                    true
                );
                this.humans.children[index].bullets.setAll(
                    "outOfBoundsKill",
                    true
                );
            },
            this
        );
    },

    checkCollision: function() {
        this.game.physics.arcade.collide(this.zombies, this.zombies);
        this.game.physics.arcade.collide(
            this.zombies,
            this.humans,
            this.turnHuman
        );
        //bullets collision
        this.humans.forEach(function(human) {
            this.game.physics.arcade.collide(
                human.bullets,
                this.zombies,
                this.damageZombie
            );
        }, this);
    },

    checkInput: function() {
        if (this.game.input.activePointer.isDown) {
            //move all zombies
            this.zombies.forEach(function(zombie) {
                this.game.physics.arcade.moveToPointer(zombie, 400);

                //if in box reset velocity
                if (
                    Phaser.Rectangle.contains(
                        zombie.body,
                        this.game.input.x,
                        this.game.input.y
                    )
                ) {
                    zombie.body.velocity.setTo(0, 0);
                } //end if
            }, this); //end forEach
        } else {
            this.zombies.forEach(function(zombie) {
                zombie.body.velocity.setTo(0, 0);
            }, this); //end forEach
        } //end else
    },
    turnHuman: function(zombie, human) {
        game.time.events.add(
            Phaser.Timer.SECOND * 2,
            function() {
                human.health -= 10;
            },
            this
        );

        if (human.health < 0) {
            GameState.zombies.add(
                new Zombie(human.position.x, human.position.y)
            );
            human.kill();
            GameState.humans.remove(human);
            GameState.score++;
        }
    },
    fire: function() {
        //fire from each sprite
        this.humans.forEach(function(human) {
            this.nextFire = this.game.time.now + this.fireRate;
            var bullet = human.bullets.getFirstDead();
            bullet.reset(human.x, human.y);
            this.game.physics.arcade.moveToXY(
                bullet,
                this.zombies.centerX,
                this.zombies.centerY,
                this.game.rnd.integerInRange(50, 300)
            );
        }, this);
    },
    damageZombie: function(bullet, zombie) {
        bullet.kill();
        zombie.health -= 10;
        if (zombie.health < 0) {
            zombie.kill();
            GameState.zombies.remove(zombie);
        }
    },
    updateZombiesTextHealth: function() {
        var tempHealth = 0; //temporary health holder
        this.zombies.forEach(function(zombie) {
            tempHealth += zombie.health;
            zombie.alpha = zombie.health / 100;
        }, this);
        this.totalHealth = tempHealth / this.zombies.length;
        this.zombiesHealthtext.text = Math.round(this.totalHealth);
        if (!this.totalHealth || this.totalHealth < 0) {
            this.zombiesHealthtext.text = "Zombies are Exterminated";
            this.game.state.start(
                "HomeState",
                true,
                false,
                "GameOver!",
                this.score
            );
        }
    }
};
