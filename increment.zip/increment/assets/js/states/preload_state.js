var PreloadState = {
    preload: function() {
        this.logo = this.game.add.sprite(
            this.game.world.centerX,
            this.game.world.centerY,
            "logo"
        );
        this.logo.anchor.set(0.5);
        this.preloadBar = this.game.add.sprite(
            10,
            this.game.world.centerY + 100,
            "bar"
        );
        this.preloadBar.width = this.game.world.width - 40;
        this.load.setPreloadSprite(this.preloadBar);

        this.load.image("zombie", "assets/images/player.png");
        this.load.image("human", "assets/images/enemy.png");
        this.load.image("bullet", "assets/images/bullet.png");
        this.load.image("zombieHeart", "assets/images/zombieHeart.png");
    },
    create: function() {
        this.game.state.start("HomeState");
    }
};
